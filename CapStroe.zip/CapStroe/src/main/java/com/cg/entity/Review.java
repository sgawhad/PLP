package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "Review")
public class Review {

	@Id
	@Column(name = "review_id")
	@GeneratedValue
	private int reviewId;

	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product product;

	@Transient
	private int productId;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	@Column(name = "customer_firstname", length = 20)
	private String customerFirstName;

	@Column(name = "product_rating")
	private int productRating;

	@Column(name = "product_comment")
	private String productComment;

	public int getReviewId() {
		return reviewId;
	}

	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getCustomerFirstName() {
		return customerFirstName;
	}

	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public int getProductRating() {
		return productRating;
	}

	public void setProductRating(int productRating) {
		this.productRating = productRating;
	}

	public String getProductComment() {
		return productComment;
	}

	public void setProductComment(String productComment) {
		this.productComment = productComment;
	}

	@Override
	public String toString() {
		return "Review [customerFirstName=" + customerFirstName + ", productRating=" + productRating
				+ ", productComment=" + productComment + "]";
	}

}