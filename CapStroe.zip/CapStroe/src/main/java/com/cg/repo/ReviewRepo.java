package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Review;

public interface ReviewRepo  extends CrudRepository<Review, Integer>{

}
