package com.cg.service;

import java.util.List;

import com.cg.entity.Product;
import com.cg.entity.Review;

public interface CapStoreService {

	String addReview(Review review);

	String updateReview(Review review);

	String deleteReview(int reviewId);

	List<Review> getProductReviewById(int productId);
	
	Product getProductByid(int productId);
	
	Review getReview (int reviewId);
	
}
