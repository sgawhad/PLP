import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FeedbackService } from '../service/feedback.service';
import { feedbackModal } from '../model/feedbackModal';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  currentRate = '1';
  selected = 0;
  hovered = 0;
  readonly = false;

  newFeedback: feedbackModal;
  constructor( private feedbackservice: FeedbackService) {
    this.newFeedback =  new feedbackModal();
  }


  ngOnInit() {
}
submit() {
  this.newFeedback.currentRate = this.currentRate;
  this.feedbackservice.add(this.newFeedback);
}
}



