import { Injectable } from '@angular/core';
import { feedbackModal } from '../model/feedbackModal';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  feedbackArray: feedbackModal[];

  constructor(private router: Router) {
    this.feedbackArray = [];
   }

   add(feedback: feedbackModal) {
    // add task to array
    this.feedbackArray.push(feedback);
    this.router.navigate(['/submit']);
  }

  display() {
    return this.feedbackArray;
  }
}
