// tslint:disable-next-line:class-name
export class feedbackModal {
  // tslint:disable-next-line:ban-types
  public customerName: string;
  public comment: string;
  public currentRate: string;
}
